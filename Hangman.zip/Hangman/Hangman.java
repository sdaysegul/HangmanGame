import java.lang.StringBuffer;
import java.util.*;
import java.io.File;
import java.io.IOException;

/**
 * Hangman 
 * @author Yigit Gorgulu, Ezgi Yavuz, Artun Cura, Irmak Demir, Yusuf Avci, Goksu Turan
 * @version 1.0, 02.02.2018
 */ 
public class Hangman
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      
      // constants
      final int INVALID_INPUT = -1;
      final int USED_LETTER = -2;
      final int GAME_OVER = -3;
      
      // variables
      Hangman hangman;
      String triedLetter;
      int tryThisResult;
      
      // program code
      hangman = new Hangman();
      
      // print all letters
      System.out.println( hangman.getAllLetters()); 
      
      triedLetter = "";
      tryThisResult = 0;
      do
      {
         // interface update
         System.out.println( "Secret Word: " + hangman.getKnownSoFar());
         System.out.println( "Used Letters: " + hangman.getUsedLetters());
         System.out.println( "Remaining tries: " + (hangman.getMaxAllowedIncorrectTries() - hangman.getNumOfIncorrectTries()));
         
         // takes and tries a given letter
         System.out.print( "Please enter a letter: ");
         triedLetter = scan.next(); 
         tryThisResult = hangman.tryThis( triedLetter.charAt(0)); // stores error code
         
         if ( tryThisResult == INVALID_INPUT)
         {
            System.out.println( "Invalid letter.");
         }
         else if ( tryThisResult == USED_LETTER)
         {
            System.out.println( "Letter is already used.");
         }
         else if ( tryThisResult == GAME_OVER)
         {
            // we would need to print the secret word but there is no method to get the secret word
            System.out.println( "Game over!");
         }
      } while ( !hangman.isGameOver());
      
      if ( hangman.hasLost())
      {
         System.out.println( "SORRY YOU LOST! :(");
      }
      else
      {
         System.out.println( "CONGRATS! YOU WON!");
      }
   }
   
   
   private StringBuffer secretWord;
   private StringBuffer allLetters;
   private StringBuffer usedLetters;
   private int          numberOfIncorrectTries;
   private int          maxAllowedIncorrectTries;
   private StringBuffer knownSoFar;
   
   //constructors
   public Hangman()
   {
      
      allLetters = new StringBuffer( "abcdefghijklmnopqrstuvwxyz" );
      maxAllowedIncorrectTries = 6;
      numberOfIncorrectTries = 0;
      usedLetters = new StringBuffer( "" );
      secretWord = chooseSecretWord();
      knownSoFar = new StringBuffer( "" );
      
      // Add *'s as the same amount of the letters in the secretWord
      for ( int i = 0; i < secretWord.length(); i++ )
      {
         knownSoFar.append( "*" );
      }
      
   }
   //methods
   
   String getAllLetters(){
      return allLetters.toString();
   }
   
   String getUsedLetters(){
      return usedLetters.toString();
   }
   
   int getNumOfIncorrectTries(){
      return numberOfIncorrectTries;
   }
   
   int getMaxAllowedIncorrectTries(){
      return maxAllowedIncorrectTries;
   }
   
   String getKnownSoFar(){
      return knownSoFar.toString();
   }
   
   int tryThis(char letter) {
      
      int count;
      boolean isCorrect;
      
      letter = Character.toLowerCase(letter);
      // Check if it is valid char.
      if ( ( letter < 'a' || letter > 'z')) {
         return -1;
      }
      
      else if ( usedLetters.indexOf( Character.toString(letter)) != -1) {
         return -2;
      }
      
      else {
         count = 0;
         usedLetters.append( Character.toString(letter));
         isCorrect = false;
         for ( int i = 0; i < secretWord.length(); i++) {
            if ( secretWord.charAt(i) == letter) {
               knownSoFar.deleteCharAt(i);
               knownSoFar.insert(i, letter);
               isCorrect = true;
               count++;
            }
         }
         
         if (!isCorrect) {
            numberOfIncorrectTries++;
         }
         
         if (isGameOver() || hasLost()){
            return -3;
         } else {
            return count;
         }
      }
   }
   
   boolean isGameOver(){
      return this.maxAllowedIncorrectTries <= this.numberOfIncorrectTries || this.knownSoFar.indexOf("*")==-1;
   }
   
   boolean hasLost(){
      return this.knownSoFar.indexOf("*")!=-1;
   }
   
   public StringBuffer chooseSecretWord(){
   String temp;
   temp = "";
   
   String[] list = { "java", "programming", "initialise", "constructor" , "method", "object", "class", "static", "compiler", "indentation" };
   
   temp = list[ (int) (Math.random() * 10 ) ];
   secretWord = new StringBuffer(temp);
   return secretWord;
   }
}
